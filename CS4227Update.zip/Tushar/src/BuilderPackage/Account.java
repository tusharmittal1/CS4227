package BuilderPackage;

public class Account
{

    private String accountName;
    private String accountPassword;
    private String accountEmail;

    public Account(String accountName, String accountPassword, String accountEmail)
    {
        super();
        this.accountName = accountName;
        this.accountPassword = accountPassword;
        this.accountEmail = accountEmail;
    }

    @Override
    public String toString()
    {
        return "Account Name: " + accountName + "\nAccount Email: " + accountEmail + "\nAccount Password: " + accountPassword;
    }

    public String getAccountName()
    {
        return accountName;
    }

    public String getAccountPassword()
    {
        return accountPassword;
    }

    public String getAccountEmail()
    {
        return accountEmail;
    }
}