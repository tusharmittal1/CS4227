package MementoPackage;

public class paymentInfo {

    private static String currentPaymentInfo;
    public static String previousInfo;

    public paymentInfo(){
        currentPaymentInfo = "";
        previousInfo = "";
    }

    public static void setCurrentPaymentInfo(String currentInfo)
    {
        previousInfo = currentPaymentInfo;
        currentPaymentInfo = currentInfo;
    }

    public static String getCurrentPaymentInfo()
    {
        return currentPaymentInfo;
    }
}
