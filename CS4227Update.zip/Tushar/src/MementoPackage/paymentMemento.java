package MementoPackage;

public class paymentMemento {
    private paymentInfo paymentinfo;

    private String copyOfCurrentInfo;
    private String copyOfPreviousInfo;

    public paymentMemento(paymentInfo paymentinfo)
    {
        this.paymentinfo = paymentinfo;
        copyOfCurrentInfo = paymentInfo.getCurrentPaymentInfo();
        copyOfPreviousInfo = paymentInfo.previousInfo;
    }

    public void restoreState(){
        paymentInfo.setCurrentPaymentInfo(copyOfCurrentInfo);
        paymentInfo.previousInfo = copyOfPreviousInfo;
    }
}
