/*This screen displays the main customer menu with
Account Details, Movie Listings, Book a Movie and
Request Refund.
 */

package UI;
import MementoPackage.paymentInfo;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class CustomerScreen{
    static Stage customerStage;

    public static void displayCustomerScreen()
    {
        customerStage = new Stage();
        customerStage.setTitle("Welcome");

        HBox hb = new HBox();
        hb.setPadding(new Insets(20,20,20,30));

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20,20,20,20));
        gridPane.setHgap(5);
        gridPane.setVgap(5);

        Label headerLabel = new Label("Welcome to CINEMACS");
        headerLabel.setFont(Font.font("Dekko", FontWeight.BOLD, 32));
        gridPane.add(headerLabel, 0,0,2,1);
        GridPane.setHalignment(headerLabel, HPos.CENTER);
        GridPane.setMargin(headerLabel, new Insets(20, 0,20,0));

        Button accountDetails = new Button("Account Details");
        accountDetails.setPrefHeight(90);
        accountDetails.setPrefWidth(800);

        /* Once the AccountDetails Button is pressed the user is brought to the account details
        screen where they can change their payment info, payment info stored on the server needs to be passed
        to this method (Could be an empty string), just use the method usersPaymentInfo.setCurrentInfo("Value here")
        to pass a value (This is for memento).
         */
        accountDetails.setOnAction(e -> {
                paymentInfo usersPaymentInfo = new paymentInfo();
                usersPaymentInfo.setCurrentPaymentInfo("Access This From Server");
                UI.accountDetails.displayAccountDetails(usersPaymentInfo);
                customerStage.close();
                });
        Button movieListing = new Button("Movies");
        movieListing.setPrefHeight(90);
        movieListing.setPrefWidth(800);
        Button newBooking = new Button("Book a Movie");
        newBooking.setPrefHeight(90);
        newBooking.setPrefWidth(800);

        /* Once the newBooking Button is pressed the user is brought to the Make a Booking
        Screen.
         */

        newBooking.setOnAction(e -> {
                    makingBooking.display();
                    customerStage.close();
                });
        Button requestRefunds = new Button("Request Refunds");
        requestRefunds.setPrefHeight(90);
        requestRefunds.setPrefWidth(800);

        gridPane.add(accountDetails, 0, 1);
        gridPane.add(movieListing, 0, 2);
        gridPane.add(newBooking, 0, 3);
        gridPane.add(requestRefunds, 0, 4);

        Scene menuScene = new Scene(gridPane, 800, 500);
        customerStage.setScene(menuScene);
        customerStage.show();
    }
}