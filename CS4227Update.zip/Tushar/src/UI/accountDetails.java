/*This screen is where the Memento is implemented
The user can change their payment info and the memento
will keep what they changed it from so they have the
ability to revert back to a different card.
 */

package UI;
import MementoPackage.paymentInfo;
import MementoPackage.paymentMemento;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class accountDetails {
    static Stage accountStage;


    public static void displayAccountDetails(paymentInfo cardInfo) {
        accountStage = new Stage();
        accountStage.setTitle("Account Details");
        createMainForm newForm = new createMainForm();
        GridPane accountPane = newForm.createRegistrationForm();
        accountControls(accountPane, cardInfo);
        Scene regScene = new Scene(accountPane, 800, 500);
        accountStage.setScene(regScene);
        accountStage.show();
    }

    public static void accountControls(GridPane accountPane, paymentInfo cardInfo){
        //This memento saves the current state of the card
        paymentMemento memento = new paymentMemento(cardInfo);

        System.out.println(cardInfo.previousInfo);
        System.out.println(cardInfo.getCurrentPaymentInfo());


        Label headerLabel = new Label("My Account");
        headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        accountPane.add(headerLabel, 0, 0, 2, 1);
        GridPane.setHalignment(headerLabel, HPos.CENTER);
        GridPane.setMargin(headerLabel, new Insets(20, 0, 20, 0));
        //Account Name set up
        Label accountName = new Label("Account Name : ");
        accountName.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        accountPane.add(accountName, 0, 1);
        //Retrieve Name from 'User' in Server
        Label accountNameValue = new Label("Whatever Name");
        accountPane.add(accountNameValue, 1, 1);
        //Email Set Up
        Label accountEmail = new Label("Account Email : ");
        accountEmail.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        accountPane.add(accountEmail, 0, 2);
        Label accountEmailValue = new Label("Whatever Email From Server");
        accountPane.add(accountEmailValue, 1, 2);
        //Card Set Up
        Label accountPaymentInfo = new Label("Payment Info : ");
        accountPaymentInfo.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        accountPane.add(accountPaymentInfo, 0, 3);
        Label accountPaymentValue = new Label(cardInfo.getCurrentPaymentInfo());

        //Put the current card info into the Memento which will be retrieved from the users account on server
        accountPane.add(accountPaymentValue, 1, 3);

        Button changePaymentInfo = new Button("Change Payment Info");
        changePaymentInfo.setDefaultButton(true);
        accountPane.add(changePaymentInfo, 0, 4, 2, 1);
        GridPane.setHalignment(changePaymentInfo, HPos.CENTER);
        Button revertPaymentInfo = new Button("Revert Payment Info");
        revertPaymentInfo.setDefaultButton(true);
        accountPane.add(revertPaymentInfo, 0, 5, 2, 1);
        GridPane.setHalignment(revertPaymentInfo, HPos.CENTER);
        changePaymentInfo.setOnAction(e -> {
            accountStage.close();
            Stage changeCard = new Stage();
            changeCard.setTitle("Enter New Card Info");
            createMainForm newCardForm = new createMainForm();
            GridPane cardPane = newCardForm.createRegistrationForm();
            TextField enterCard = new TextField();
            GridPane.setHalignment(enterCard, HPos.CENTER);
            cardPane.add(enterCard, 0, 0, 2, 1);
            Scene newScene = new Scene(cardPane, 400, 200);
            changeCard.setScene(newScene);
            changeCard.show();

            Button changedCard = new Button("Continue");
            changedCard.setDefaultButton(true);
            cardPane.add(changedCard, 0, 4, 2, 1);
            GridPane.setHalignment(changedCard, HPos.CENTER);
            changedCard.setOnAction(r -> {
                //This will change the card value in the server
                cardInfo.setCurrentPaymentInfo(enterCard.getText());
                accountPaymentValue.setText(cardInfo.getCurrentPaymentInfo());
                changeCard.close();
                accountStage.showAndWait();
            });
        });


        /*This button will use the memento to revert the current card details to the previous one
        Could be useful for choosing payment info like on Amazon
         */

        revertPaymentInfo.setOnAction(s -> {
            if (cardInfo.previousInfo != null)
            {
                memento.restoreState();
                accountPaymentValue.setText(cardInfo.getCurrentPaymentInfo());
                accountStage.showAndWait();
            }
            else
                System.out.println("No previous info available");
        });
        Button returnToMainScreen = new Button("Return");
        returnToMainScreen.setDefaultButton(true);
        accountPane.add(returnToMainScreen, 0, 6, 2, 1);
        GridPane.setHalignment(returnToMainScreen, HPos.CENTER);
        returnToMainScreen.snappedBottomInset();
        returnToMainScreen.setOnAction(a -> {
            CustomerScreen.displayCustomerScreen();
            accountStage.close();
        });

    }
}