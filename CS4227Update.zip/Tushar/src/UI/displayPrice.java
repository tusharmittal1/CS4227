package UI;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.Window;

public class displayPrice {
    static Stage priceStage;

    public static void displayThePrice()
    {
        priceStage = new Stage();
        priceStage.setTitle("Sign Up");
        createMainForm newForm = new createMainForm();
        GridPane pricePane = newForm.createRegistrationForm();
        priceControls(pricePane);
        Scene regScene = new Scene(pricePane, 800, 500);
        priceStage.setScene(regScene);
        priceStage.show();
    }

    public static void priceControls(GridPane pricePane)
    {
        Label headerLabel = new Label("Book Your Movie.");
        headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        pricePane.add(headerLabel, 0, 0, 2, 1);
        GridPane.setHalignment(headerLabel, HPos.CENTER);
        GridPane.setMargin(headerLabel, new Insets(20, 0, 20, 0));

        Label accountName = new Label("Cost of Ticket");
        pricePane.add(accountName, 0, 1);
        Label accountNameValue = new Label("Whatever value is calculated by the server");
        pricePane.add(accountNameValue, 1, 1);

        Label paymentInfoUsed = new Label("Payment Info");
        pricePane.add(paymentInfoUsed, 0, 2);
        Label theInfo = new Label("Get the payment info being used now");
        pricePane.add(theInfo, 1, 2);

        Label seatChosen = new Label("Seat number : ");
        pricePane.add(seatChosen, 0, 3);
        Label seatInfo = new Label("get the seat info");
        pricePane.add(seatInfo, 1, 3);

        Label movieChosen = new Label("Movie : ");
        pricePane.add(movieChosen, 0, 4);
        Label movieInfo = new Label("Insert Movie here");
        pricePane.add(movieInfo, 1, 4);

        Label timeChosen = new Label("Time Chosen : ");
        pricePane.add(timeChosen, 0, 5);
        Label timeInfo = new Label("get the time info");
        pricePane.add(timeInfo, 1, 5);

        Button payButton = new Button("Pay With Current Card");
        payButton.setDefaultButton(true);
        pricePane.add(payButton, 0, 6, 2, 1);
        GridPane.setHalignment(payButton, HPos.CENTER);
        payButton.setOnAction(q -> {
            showAlert(Alert.AlertType.INFORMATION, pricePane.getScene().getWindow(), "Enjoy The Film", "You Have Completed Your Booking");
        });
    }
    private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message)
    {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
        alert.setOnCloseRequest(r -> {
            priceStage.close();
            CustomerScreen.displayCustomerScreen();
        });
    }
}
