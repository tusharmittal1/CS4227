/* This screen displays the loginscreen,
here you are able to login using credentials
stored on the server */

package UI;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.Window;

public class loginScreen{
    static Stage loginScreenStage;
    static CustomerScreen newCustomerScreen;

    public static void displayLoginScreen(){

        loginScreenStage = new Stage();
        loginScreenStage.setTitle("Login");

        createMainForm newForm = new createMainForm();
        GridPane loginPane = newForm.createRegistrationForm();

        addLoginControls(loginPane);
        Scene loginScene = new Scene(loginPane, 800, 500);
        loginScreenStage.setScene(loginScene);
        loginScreenStage.show();
    }


    private static void addLoginControls(GridPane loginPane)
    {
        // Adds the header to the pane
        Label headerLabel = new Label("Log In");
        headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        loginPane.add(headerLabel, 0,0,2,1);
        GridPane.setHalignment(headerLabel, HPos.CENTER);
        GridPane.setMargin(headerLabel, new Insets(20, 0,20,0));

       //Add Username
        Label nameLabel = new Label("Username: ");
        loginPane.add(nameLabel, 0,1);
        TextField nameField = new TextField();
        nameField.setPrefHeight(40);
        loginPane.add(nameField, 1,1);

        //Add Password
        Label passwordLabel = new Label("Password : ");
        loginPane.add(passwordLabel, 0, 3);
        PasswordField passwordField = new PasswordField();
        passwordField.setPrefHeight(40);
        loginPane.add(passwordField, 1, 3);

        //Add Button
        Button submitButton = new Button("Submit");
        submitButton.setPrefHeight(40);
        submitButton.setDefaultButton(true);
        submitButton.setPrefWidth(100);
        GridPane.setHalignment(submitButton, HPos.CENTER);
        loginPane.add(submitButton, 0, 4, 2, 1);
        GridPane.setMargin(submitButton, new Insets(20, 20, 20, 0));

        /*If the fields are empty or login isn't recognised by server an error should be shown
        otherwise the user should continue on to the customer screen.
         */

        submitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(nameField.getText().isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, loginPane.getScene().getWindow(), "Form Error!", "Please enter your name");
                    return;
                }
                if(passwordField.getText().isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, loginPane.getScene().getWindow(), "Form Error!", "Please enter a password");
                    return;
                }
                else
                    newCustomerScreen = new CustomerScreen();
                    System.out.println("Login Details\n" + nameField.getText() + "\n" + passwordField.getText());
                    newCustomerScreen.displayCustomerScreen();
                    loginScreenStage.close();

            }
        });
    }
    private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message)
    {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
}