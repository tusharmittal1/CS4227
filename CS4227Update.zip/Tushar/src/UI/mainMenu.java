/*This is the start of the program,
this initiates the JavaFX from the main method
and displays the screen in which you can Login or Register */

package UI;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.Window;

public class mainMenu extends Application{
    @Override
    public void start(Stage primaryStage) throws Exception
    {
        primaryStage.setTitle("Welcome to CinEMACS");

        //CreateMainForm creates a general template for the Scenes
        createMainForm newForm = new createMainForm();
        GridPane menuPane = newForm.createRegistrationForm();

        addUIControls(menuPane, primaryStage);
        Scene mainMenuScene = new Scene(menuPane, 800, 500);
        primaryStage.setScene(mainMenuScene);
        primaryStage.show();
    }

    private void addUIControls(GridPane menuPane, Stage window)
    {
        Label headerLabel = new Label("Welcome to CINEMACS");
        headerLabel.setFont(Font.font("Dekko", FontWeight.BOLD, 32));
        menuPane.add(headerLabel, 0,0,2,1);
        GridPane.setHalignment(headerLabel, HPos.CENTER);
        GridPane.setMargin(headerLabel, new Insets(20, 0,20,0));

        //Creating the LoginButton
        Button loginButton = new Button("Login");
        loginButton.setPrefHeight(60);
        loginButton.setDefaultButton(true);
        loginButton.setPrefWidth(400);
        menuPane.add(loginButton, 0, 4, 2, 1);
        GridPane.setHalignment(loginButton, HPos.CENTER);
        GridPane.setMargin(loginButton, new Insets(20, 0,20,0));

        //Creating the RegisterButton
        Button regButton = new Button("Register");
        regButton.setPrefHeight(60);
        regButton.setDefaultButton(true);
        regButton.setPrefWidth(400);
        menuPane.add(regButton, 0, 5, 2, 1);
        GridPane.setHalignment(regButton, HPos.CENTER);
        GridPane.setMargin(regButton, new Insets(20, 0,20,0));

        //Once LoginButton is pressed it goes to the login screen.
        loginButton.setOnAction(e -> {
            loginScreen.displayLoginScreen();
            window.close();
        });

        //Once RegButton is pressed it goes to the register screen.
        regButton.setOnAction(e -> {
            registerScreen.displayRegisterScreen();
            window.close();
        });
    }
    private void showAlert(Alert.AlertType alertType, Window owner, String title, String message)
    {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }

    //Start of program.
    public static void main (String [] args)
    {
        launch(args);
    }
}