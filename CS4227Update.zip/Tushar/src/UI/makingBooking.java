package UI;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class makingBooking {
    private static Stage bookingStage;

    public static void display() {

        bookingStage = new Stage();
        bookingStage.setTitle("Choose your Movie");
        createMainForm movieChoice = new createMainForm();
        GridPane moviePane = movieChoice.createRegistrationForm();
        bookingControls(moviePane);
        Scene bookingScene = new Scene(moviePane, 800, 500);
        bookingStage.setScene(bookingScene);
        bookingStage.show();

    }

    public static void bookingControls(GridPane gridPane) {

        Label headerLabel = new Label("Book Your Movie.");
        headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        gridPane.add(headerLabel, 0, 0, 2, 1);
        GridPane.setHalignment(headerLabel, HPos.CENTER);
        GridPane.setMargin(headerLabel, new Insets(20, 0, 20, 0));

        Label chooseMovie = new Label("Choose Movie : ");
        gridPane.add(chooseMovie, 0, 1);

        ChoiceBox<String> movieList = new ChoiceBox<>();

        //Add temporary list to the movieList until we get server working (Will be getMovieListings)

        movieList.getItems().addAll("The Joker: Starring Joaquin Pheonix", "Infinity War: Starring The Avengers", "Pixars: The Incredibles", "Other Movie", "Another Movie");
        gridPane.add(movieList, 0, 1, 2, 1);
        movieList.setPrefWidth(400);
        GridPane.setHalignment(movieList, HPos.CENTER);
        movieList.getSelectionModel().select(0);


        RadioButton studentKey = new RadioButton("Student / Child");
        gridPane.add(studentKey, 0, 2, 2, 1);
        GridPane.setHalignment(studentKey, HPos.CENTER);

        RadioButton AdultKey = new RadioButton("Adult");
        gridPane.add(AdultKey, 1, 2);

        Label availableTimes = new Label("Choose Time : ");
        gridPane.add(availableTimes, 0, 3);

        //Same with times of showings (Will be getMovieSchedule)

        ChoiceBox<String> aT = new ChoiceBox<>();
        aT.getItems().addAll("19:30", "21:00", "23:00", "07:00", "14:00");
        gridPane.add(aT, 0, 3, 2, 1);
        aT.setPrefWidth(400);
        GridPane.setHalignment(aT, HPos.CENTER);

        aT.getSelectionModel().select(0);

        Button nextPage = new Button("Continue");
        nextPage.setDefaultButton(true);
        gridPane.add(nextPage, 0, 4, 2, 1);
        GridPane.setHalignment(nextPage, HPos.CENTER);

        //Once the user presses continue the Program will get all the inputs (Movie, Adult or Student/Child and Movie Time

        nextPage.setOnAction(e -> {
            String isAdult = "Adult";
            aT.getSelectionModel().getSelectedItem();
            movieList.getSelectionModel().getSelectedItem();
            if (AdultKey.isSelected()) {
                isAdult = "Adult";
            } else if (studentKey.isSelected()) {
                isAdult = "Student";
            }
            System.out.println(aT.getSelectionModel().getSelectedItem());
            System.out.println(movieList.getSelectionModel().getSelectedItem());
            System.out.println(isAdult);

            // Can pass parameters to seats to determine the number of seats available for a given movie

            seats.displaySeats();
            bookingStage.close();
        });
        Button returnToMainScreen = new Button("Return");
        returnToMainScreen.setDefaultButton(true);
        gridPane.add(returnToMainScreen, 0, 5, 2, 1);
        GridPane.setHalignment(returnToMainScreen, HPos.CENTER);
        returnToMainScreen.snappedBottomInset();
        returnToMainScreen.setOnAction(s -> {
            CustomerScreen.displayCustomerScreen();
            bookingStage.close();
        });

    }
}