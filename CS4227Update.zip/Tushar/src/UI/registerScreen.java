/* This is the register screen where you will be allowed to
create a new account on the server and Login
 */

package UI;
import BuilderPackage.accountBuilder;
import BuilderPackage.Account;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;

public class registerScreen{
    public static Stage registerStage;
    static Account newAccount;

    public static void displayRegisterScreen()
    {
        registerStage = new Stage();
        registerStage.setTitle("Sign Up");
        createMainForm newForm = new createMainForm();
        GridPane regPane = newForm.createRegistrationForm();
        addRegisterControls(regPane);
        Scene regScene = new Scene(regPane, 800, 500);
        registerStage.setScene(regScene);
        registerStage.show();
    }

    private static void addRegisterControls(GridPane regPane)
    {
        Label headerLabel = new Label("Sign Up");
        headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        regPane.add(headerLabel, 0,0,2,1);
        GridPane.setHalignment(headerLabel, HPos.CENTER);
        GridPane.setMargin(headerLabel, new Insets(20, 0,20,0));

        Label nameLabel = new Label("Full Name : ");
        regPane.add(nameLabel, 0,1);
        TextField nameField = new TextField();
        nameField.setPrefHeight(40);
        regPane.add(nameField, 1,1);

        Label emailLabel = new Label("Email ID : ");
        regPane.add(emailLabel, 0, 2);
        TextField emailField = new TextField();
        emailField.setPrefHeight(40);
        regPane.add(emailField, 1, 2);

        Label passwordLabel = new Label("Password : ");
        regPane.add(passwordLabel, 0, 3);
        PasswordField passwordField = new PasswordField();
        passwordField.setPrefHeight(40);
        regPane.add(passwordField, 1, 3);

        Label confirmPasswordLabel = new Label("Confirm Password : ");
        regPane.add(confirmPasswordLabel, 0, 4);
        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPrefHeight(40);
        regPane.add(confirmPasswordField, 1,4);

        Button submitButton = new Button("Submit");
        submitButton.setPrefHeight(40);
        submitButton.setDefaultButton(true);
        submitButton.setPrefWidth(100);
        regPane.add(submitButton, 0, 8, 2, 1);
        GridPane.setHalignment(submitButton, HPos.CENTER);
        GridPane.setMargin(submitButton, new Insets(20, 0,20,0));

        Button returnButton = new Button("Log In");
        returnButton.setPrefHeight(40);
        returnButton.setDefaultButton(true);
        returnButton.setPrefWidth(100);
        regPane.add(returnButton, 1, 8, 7, 1);
        GridPane.setHalignment(returnButton, HPos.CENTER);
        GridPane.setMargin(returnButton, new Insets(20, 0,20,0));
        Stage window = new Stage();

        //If you press returnButton you will be brought to the Login Screen

        returnButton.setOnAction(e -> {
            loginScreen.displayLoginScreen();
            registerStage.close();
        });

        //The submit button will validate all the input to make sure its not empty and in the correct format

        submitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String pattern = "[a-z]{1,15} [a-z]{1,15}";
                String emailPattern = "[A-Za-z0-9]{1,}@[A-Za-z]{1,15}.com";
                String passwordPattern = "[A-Za-z0-9]{5,20}";
                if(nameField.getText().isEmpty() || emailField.getText().isEmpty() || passwordField.getText().isEmpty() || confirmPasswordField.getText().isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, regPane.getScene().getWindow(), "Form Error!", "One of the required fields is empty");
                    return;
                }
                else if (!(nameField.getText().toLowerCase().matches(pattern)))
                {
                    showAlert(Alert.AlertType.ERROR, regPane.getScene().getWindow(), "Form Error!", "Full name doesn't match the expected input (No Numbers and A Full Name i.e John Doe");
                    return;
                }
                else if (!(emailField.getText().matches(emailPattern)))
                {
                    showAlert(Alert.AlertType.ERROR, regPane.getScene().getWindow(), "Form Error!", "Email doesn't match the expected input ([A-Za-z0-9]{1,}@[A-Za-z]{1,15}.com)");
                    return;
                }
                else if (!(passwordField.getText().matches(passwordPattern)))
                {
                    showAlert(Alert.AlertType.ERROR, regPane.getScene().getWindow(), "Form Error!", "Password doesn't match the expected input (Between 5 and 20 characters)");
                    return;
                }
                else if (!(confirmPasswordField.getText().matches(passwordField.getText())))
                {
                    showAlert(Alert.AlertType.ERROR, regPane.getScene().getWindow(), "Form Error!", "Confirm Password doesn't match the original password");
                    return;
                }
                /* Once successfully registered a newAccount will be created using a
                builder as shown below and the Login screen will be displayed.
                All data for the new user is in
                 */
                else
                newAccount = new accountBuilder().setAccountName(nameField.getText().toUpperCase()).setAccountPassword(passwordField.getText()).setAccountEmail(emailField.getText()).getAccount();
                System.out.print(newAccount.toString());
                loginScreen.displayLoginScreen();
                registerStage.close();
            }
        });
    }
    private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message)
    {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
}