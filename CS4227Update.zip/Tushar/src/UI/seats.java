package UI;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class seats{
   private static Button[] buttons;

    public static void displaySeats(){
        Stage primaryStage = new Stage();
        primaryStage.setTitle("Choose your seats!");
        buttons = new Button[15];
        GridPane gridPane = new GridPane();
        for (int i = 0; i < buttons.length; i++){
            Button butt = new Button("Seat " + i);
            butt.setPrefWidth(100);
            butt.setPrefHeight(100);
            buttons[i] = butt;
            if (i < 5) {
                gridPane.addColumn(i, buttons[i]);
            }
            else if (i < 10) {
                gridPane.add(buttons[i], i - 5, 1);
            }
            else{
                gridPane.add(buttons[i], i - 10, 2);
            }
        }
        Button buttonContinue = new Button("Continue");
        buttonContinue.setPrefSize(100,80);
        buttonContinue.snappedBottomInset();
        buttonContinue.setOnAction(e -> displayPrice.displayThePrice());
        gridPane.add(buttonContinue, 2, 3);
        Scene seatScene = new Scene(gridPane, 500, 300);
        primaryStage.setScene(seatScene);
        primaryStage.show();
    }
}